// ------------------------------------
// Windows Event Log
// ------------------------------------

module.exports = {
  init (logger, conf) {

  }
}
